import tempfile
import unittest

from pathlib import Path
from unittest.mock import patch

from src.settings import DEFAULT_SETTINGS

from src.hardware_detection import get_hardware_info

from src.qemu_manager import QEMUManager


class HardwareTests(unittest.TestCase):

    def test_cpu(self):
        info = get_hardware_info()

        self.assertGreater(
            info["cpu_count"],
            0
        )

    def test_memory(self):
        info = get_hardware_info()

        self.assertGreater(
            info["ram_total"],
            0
        )


class SettingsTests(unittest.TestCase):

    def test_ram(self):
        self.assertGreaterEqual(
            DEFAULT_SETTINGS["ram"],
            4096
        )

    def test_cpu(self):
        self.assertGreater(
            DEFAULT_SETTINGS["cpu"],
            0
        )

    def test_disk(self):
        self.assertGreaterEqual(
            DEFAULT_SETTINGS["disk_size"],
            64
        )


class QEMUTests(unittest.TestCase):

    def test_executable_paths(self):
        qemu = QEMUManager()

        self.assertEqual(
            qemu.qemu_exe.name,
            "qemu-system-x86_64.exe"
        )

        self.assertEqual(
            qemu.qemu_img.name,
            "qemu-img.exe"
        )

    def test_configuration(self):
        qemu = QEMUManager()

        with tempfile.TemporaryDirectory() as temp:
            disk = Path(temp) / "windows.qcow2"
            disk.touch()

            settings = DEFAULT_SETTINGS.copy()

            settings["disk"] = str(disk)
            settings["iso"] = ""

            original_is_file = Path.is_file

            def mocked_is_file(path):
                if path == qemu.qemu_exe:
                    return True

                return original_is_file(path)

            with patch.object(
                Path,
                "is_file",
                mocked_is_file
            ):
                command = qemu.build_command(
                    settings,
                    use_whpx=True
                )

            self.assertIn(
                "whpx",
                command
            )

            self.assertIn(
                "4096",
                command
            )


if __name__ == "__main__":
    unittest.main()