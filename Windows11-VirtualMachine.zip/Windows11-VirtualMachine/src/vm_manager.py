import subprocess

from pathlib import Path

from .qemu_manager import QEMUManager


class VMManager:
    def __init__(self):
        self.qemu = QEMUManager()
        self.process = None

    def is_running(self):
        return (
            self.process is not None
            and self.process.poll() is None
        )

    def create_vm(self, settings):
        if self.is_running():
            raise RuntimeError(
                "Нельзя создавать диск работающей ВМ"
            )

        disk = Path(settings["disk"])

        if disk.exists():
            return

        self.qemu.create_disk(
            disk,
            settings["disk_size"]
        )

    def start(self, settings, use_whpx=True):
        if self.is_running():
            raise RuntimeError(
                "Виртуальная машина уже запущена"
            )

        command = self.qemu.build_command(
            settings,
            use_whpx
        )

        self.process = subprocess.Popen(
            command,
            cwd=str(self.qemu.qemu_dir)
        )

        return self.process

    def stop(self):
        if not self.is_running():
            return

        self.process.terminate()

        try:
            self.process.wait(timeout=15)

        except subprocess.TimeoutExpired:
            self.process.kill()
            self.process.wait(timeout=5)

    def restart(self, settings, use_whpx=True):
        self.stop()

        return self.start(
            settings,
            use_whpx
        )

    def create_snapshot(self, settings, name):
        if self.is_running():
            raise RuntimeError(
                "Сначала выключите виртуальную машину"
            )

        self.qemu.create_snapshot(
            settings["disk"],
            name
        )

    def restore_snapshot(self, settings, name):
        if self.is_running():
            raise RuntimeError(
                "Сначала выключите виртуальную машину"
            )

        self.qemu.restore_snapshot(
            settings["disk"],
            name
        )