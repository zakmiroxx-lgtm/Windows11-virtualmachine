import json
import os

from pathlib import Path


APP_NAME = "Windows11VirtualMachine"


def get_data_directory():
    base = os.environ.get(
        "LOCALAPPDATA",
        str(Path.home())
    )

    directory = Path(base) / APP_NAME

    directory.mkdir(
        parents=True,
        exist_ok=True
    )

    return directory


DATA_DIR = get_data_directory()

SETTINGS_FILE = DATA_DIR / "settings.json"


DEFAULT_SETTINGS = {
    "ram": 4096,
    "cpu": 2,
    "disk_size": 64,
    "disk": str(DATA_DIR / "windows.qcow2"),
    "iso": ""
}


def load_settings():
    settings = DEFAULT_SETTINGS.copy()

    if SETTINGS_FILE.exists():
        try:
            with open(
                SETTINGS_FILE,
                "r",
                encoding="utf-8"
            ) as file:
                loaded = json.load(file)

            if isinstance(loaded, dict):
                settings.update(loaded)

        except (OSError, ValueError, TypeError):
            pass

    return settings


def save_settings(settings):
    temporary = SETTINGS_FILE.with_suffix(".tmp")

    with open(
        temporary,
        "w",
        encoding="utf-8"
    ) as file:
        json.dump(
            settings,
            file,
            indent=4,
            ensure_ascii=False
        )

    temporary.replace(SETTINGS_FILE)