import subprocess
import sys

from pathlib import Path


def application_root():
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent

    return Path(__file__).resolve().parent.parent


class QEMUManager:
    def __init__(self):
        self.root = application_root()

        self.qemu_dir = self.root / "qemu"

        self.qemu_exe = (
            self.qemu_dir / "qemu-system-x86_64.exe"
        )

        self.qemu_img = (
            self.qemu_dir / "qemu-img.exe"
        )

    def check_installation(self):
        return (
            self.qemu_exe.is_file()
            and self.qemu_img.is_file()
        )

    def find_uefi(self):
        candidates = [
            "edk2-x86_64-code.fd",
            "OVMF_CODE.fd",
            "share/edk2-x86_64-code.fd",
            "share/OVMF_CODE.fd"
        ]

        for candidate in candidates:
            path = self.qemu_dir / candidate

            if path.is_file():
                return path

        return None

    def create_disk(self, path, size_gb):
        if not self.qemu_img.is_file():
            raise FileNotFoundError(
                "qemu-img.exe не найден"
            )

        path = Path(path)

        if path.exists():
            raise FileExistsError(
                "Виртуальный диск уже существует"
            )

        path.parent.mkdir(
            parents=True,
            exist_ok=True
        )

        subprocess.run(
            [
                str(self.qemu_img),
                "create",
                "-f",
                "qcow2",
                str(path),
                f"{size_gb}G"
            ],
            check=True,
            timeout=120
        )

    def build_command(
        self,
        settings,
        use_whpx=True
    ):
        if not self.qemu_exe.is_file():
            raise FileNotFoundError(
                "QEMU не найден"
            )

        disk = Path(settings["disk"])

        if not disk.is_file():
            raise FileNotFoundError(
                "Виртуальный диск не найден"
            )

        command = [
            str(self.qemu_exe),

            "-machine",
            "q35",

            "-m",
            str(settings["ram"]),

            "-smp",
            str(settings["cpu"]),

            "-drive",
            (
                f"file={disk},"
                "format=qcow2,"
                "if=ide"
            ),

            "-device",
            "qemu-xhci",

            "-device",
            "usb-tablet",

            "-device",
            "usb-kbd",

            "-nic",
            "user,model=e1000",

            "-vga",
            "std",

            "-display",
            "sdl",

            "-audiodev",
            "dsound,id=audio0",

            "-device",
            "ich9-intel-hda",

            "-device",
            "hda-output,audiodev=audio0"
        ]

        if use_whpx:
            command.extend([
                "-accel",
                "whpx"
            ])
        else:
            command.extend([
                "-accel",
                "tcg"
            ])

        uefi = self.find_uefi()

        if uefi:
            command.extend([
                "-drive",
                (
                    "if=pflash,"
                    "format=raw,"
                    "readonly=on,"
                    f"file={uefi}"
                )
            ])

        iso = settings.get("iso", "")

        if iso and Path(iso).is_file():
            command.extend([
                "-drive",
                (
                    f"file={iso},"
                    "media=cdrom,"
                    "if=ide,"
                    "readonly=on"
                ),

                "-boot",
                "order=d"
            ])

        return command

    def create_snapshot(self, disk, name):
        subprocess.run(
            [
                str(self.qemu_img),
                "snapshot",
                "-c",
                name,
                str(disk)
            ],
            check=True,
            timeout=120
        )

    def restore_snapshot(self, disk, name):
        subprocess.run(
            [
                str(self.qemu_img),
                "snapshot",
                "-a",
                name,
                str(disk)
            ],
            check=True,
            timeout=120
        )

    def list_snapshots(self, disk):
        result = subprocess.run(
            [
                str(self.qemu_img),
                "snapshot",
                "-l",
                str(disk)
            ],
            capture_output=True,
            text=True,
            check=True,
            timeout=120
        )

        return result.stdout