import os
import webbrowser

from pathlib import Path

import psutil

from PySide6.QtCore import QTimer

from PySide6.QtWidgets import (
    QMainWindow,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QPushButton,
    QLabel,
    QSpinBox,
    QFileDialog,
    QMessageBox,
    QGroupBox,
    QInputDialog,
    QProgressBar
)

from .settings import load_settings, save_settings

from .vm_manager import VMManager

from .hardware_detection import (
    get_hardware_info,
    check_whpx,
    enable_whpx
)


STYLE = """
QMainWindow {
    background-color: #101218;
}

QWidget {
    color: white;
    font-family: 'Segoe UI';
    font-size: 13px;
}

QGroupBox {
    background-color: #1b1e27;
    border: 1px solid #343849;
    border-radius: 12px;
    margin-top: 12px;
    padding: 18px;
}

QPushButton {
    background-color: #303649;
    border: none;
    border-radius: 8px;
    padding: 11px;
}

QPushButton:hover {
    background-color: #414b65;
}

QPushButton:disabled {
    background-color: #242733;
    color: #777777;
}

QPushButton#primary {
    background-color: #3978f6;
    font-weight: bold;
    font-size: 15px;
}

QPushButton#primary:hover {
    background-color: #5590ff;
}

QSpinBox {
    background-color: #282d3a;
    border: 1px solid #41485b;
    padding: 7px;
    border-radius: 6px;
}

QProgressBar {
    background-color: #282d3a;
    border: none;
    border-radius: 5px;
    height: 12px;
}

QProgressBar::chunk {
    background-color: #3978f6;
    border-radius: 5px;
}
"""


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.settings = load_settings()

        self.vm = VMManager()

        self.setWindowTitle(
            "Windows11 Virtual Machine"
        )

        self.resize(850, 700)

        self.setStyleSheet(STYLE)

        self.setup_ui()

        self.timer = QTimer(self)

        self.timer.timeout.connect(
            self.update_status
        )

        self.timer.start(1000)

        self.update_status()

    def setup_ui(self):
        central = QWidget()

        self.setCentralWidget(central)

        layout = QVBoxLayout(central)

        layout.setSpacing(15)

        title = QLabel(
            "🖥 Windows 11 Virtual Machine"
        )

        title.setStyleSheet(
            "font-size: 25px; font-weight: bold;"
        )

        layout.addWidget(title)

        layout.addWidget(
            QLabel("Виртуальная машина на базе QEMU")
        )

        self.status = QLabel(
            "● Виртуальная машина выключена"
        )

        layout.addWidget(self.status)

        controls = QHBoxLayout()

        self.create_button = QPushButton(
            "Создать Windows"
        )

        self.start_button = QPushButton(
            "▶ Запустить Windows"
        )

        self.start_button.setObjectName(
            "primary"
        )

        self.stop_button = QPushButton(
            "■ Выключить"
        )

        self.restart_button = QPushButton(
            "↻ Перезагрузить"
        )

        for button in [
            self.create_button,
            self.start_button,
            self.stop_button,
            self.restart_button
        ]:
            controls.addWidget(button)

        layout.addLayout(controls)

        settings_group = QGroupBox(
            "Настройки виртуальной машины"
        )

        settings_layout = QVBoxLayout()

        cpu_row = QHBoxLayout()

        cpu_row.addWidget(
            QLabel("CPU:")
        )

        self.cpu_spin = QSpinBox()

        self.cpu_spin.setRange(
            1,
            os.cpu_count() or 4
        )

        self.cpu_spin.setValue(
            self.settings["cpu"]
        )

        cpu_row.addWidget(
            self.cpu_spin
        )

        settings_layout.addLayout(cpu_row)

        ram_row = QHBoxLayout()

        ram_row.addWidget(
            QLabel("RAM (MB):")
        )

        self.ram_spin = QSpinBox()

        self.ram_spin.setRange(
            1024,
            65536
        )

        self.ram_spin.setSingleStep(1024)

        self.ram_spin.setValue(
            self.settings["ram"]
        )

        ram_row.addWidget(
            self.ram_spin
        )

        settings_layout.addLayout(ram_row)

        disk_row = QHBoxLayout()

        disk_row.addWidget(
            QLabel("Размер диска (GB):")
        )

        self.disk_spin = QSpinBox()

        self.disk_spin.setRange(
            20,
            2048
        )

        self.disk_spin.setValue(
            self.settings["disk_size"]
        )

        disk_row.addWidget(
            self.disk_spin
        )

        settings_layout.addLayout(disk_row)

        self.iso_button = QPushButton(
            "Выбрать ISO Windows"
        )

        settings_layout.addWidget(
            self.iso_button
        )

        self.iso_label = QLabel(
            self.settings["iso"] or "ISO не выбран"
        )

        self.iso_label.setWordWrap(True)

        settings_layout.addWidget(
            self.iso_label
        )

        self.whpx_button = QPushButton(
            "Включить WHPX"
        )

        settings_layout.addWidget(
            self.whpx_button
        )

        settings_group.setLayout(
            settings_layout
        )

        layout.addWidget(settings_group)

        snapshot_group = QGroupBox(
            "Снимки виртуальной машины"
        )

        snapshot_layout = QHBoxLayout()

        self.snapshot_button = QPushButton(
            "Создать снимок"
        )

        self.restore_button = QPushButton(
            "Восстановить"
        )

        self.list_button = QPushButton(
            "Список снимков"
        )

        snapshot_layout.addWidget(
            self.snapshot_button
        )

        snapshot_layout.addWidget(
            self.restore_button
        )

        snapshot_layout.addWidget(
            self.list_button
        )

        snapshot_group.setLayout(
            snapshot_layout
        )

        layout.addWidget(snapshot_group)

        hardware_group = QGroupBox(
            "Использование компьютера"
        )

        hardware_layout = QVBoxLayout()

        self.cpu_label = QLabel(
            "CPU: 0%"
        )

        self.cpu_progress = QProgressBar()

        self.cpu_progress.setRange(
            0,
            100
        )

        self.ram_label = QLabel(
            "RAM: 0%"
        )

        self.ram_progress = QProgressBar()

        self.ram_progress.setRange(
            0,
            100
        )

        hardware_layout.addWidget(
            self.cpu_label
        )

        hardware_layout.addWidget(
            self.cpu_progress
        )

        hardware_layout.addWidget(
            self.ram_label
        )

        hardware_layout.addWidget(
            self.ram_progress
        )

        hardware_group.setLayout(
            hardware_layout
        )

        layout.addWidget(hardware_group)

        self.hardware_label = QLabel()

        layout.addWidget(
            self.hardware_label
        )

        layout.addStretch()

        self.create_button.clicked.connect(
            self.create_vm
        )

        self.start_button.clicked.connect(
            self.start_vm
        )

        self.stop_button.clicked.connect(
            self.stop_vm
        )

        self.restart_button.clicked.connect(
            self.restart_vm
        )

        self.iso_button.clicked.connect(
            self.select_iso
        )

        self.whpx_button.clicked.connect(
            self.activate_whpx
        )

        self.snapshot_button.clicked.connect(
            self.create_snapshot
        )

        self.restore_button.clicked.connect(
            self.restore_snapshot
        )

        self.list_button.clicked.connect(
            self.list_snapshots
        )

        info = get_hardware_info()

        self.hardware_label.setText(
            f"CPU: {info['cpu_count']} потоков | "
            f"RAM: {info['ram_total']} GB | "
            f"WHPX: {'включён' if check_whpx() else 'не обнаружен'}"
        )

    def save_ui_settings(self):
        if self.vm.is_running():
            return

        self.settings["cpu"] = (
            self.cpu_spin.value()
        )

        self.settings["ram"] = (
            self.ram_spin.value()
        )

        self.settings["disk_size"] = (
            self.disk_spin.value()
        )

        save_settings(
            self.settings
        )

    def show_error(self, error):
        QMessageBox.critical(
            self,
            "Ошибка",
            str(error)
        )

    def select_iso(self):
        filename, _ = QFileDialog.getOpenFileName(
            self,
            "Выберите ISO Windows",
            "",
            "ISO Images (*.iso)"
        )

        if filename:
            self.settings["iso"] = filename

            self.iso_label.setText(
                filename
            )

            save_settings(
                self.settings
            )

    def activate_whpx(self):
        answer = QMessageBox.question(
            self,
            "Включение WHPX",
            "Для включения компонента Windows "
            "могут потребоваться права администратора "
            "и перезагрузка.\n\nПродолжить?"
        )

        if answer != QMessageBox.Yes:
            return

        try:
            result = enable_whpx()

            if result.returncode == 0:
                QMessageBox.information(
                    self,
                    "WHPX",
                    "Команда выполнена.\n"
                    "Для применения изменений "
                    "может потребоваться перезагрузка."
                )
            else:
                self.show_error(
                    result.stderr or result.stdout
                )

        except Exception as error:
            self.show_error(error)

    def create_vm(self):
        try:
            self.save_ui_settings()

            if not self.settings["iso"]:
                answer = QMessageBox.question(
                    self,
                    "ISO Windows",
                    "ISO не выбран.\n"
                    "Открыть официальный сайт Microsoft?"
                )

                if answer == QMessageBox.Yes:
                    webbrowser.open(
                        "https://www.microsoft.com/"
                        "software-download/windows11"
                    )

                return

            self.vm.create_vm(
                self.settings
            )

            QMessageBox.information(
                self,
                "Готово",
                "Виртуальный диск подготовлен."
            )

        except Exception as error:
            self.show_error(error)

    def start_vm(self):
        try:
            self.save_ui_settings()

            if not Path(
                self.settings["disk"]
            ).exists():
                self.vm.create_vm(
                    self.settings
                )

            self.vm.start(
                self.settings,
                use_whpx=check_whpx()
            )

        except Exception as error:
            self.show_error(error)

    def stop_vm(self):
        if not self.vm.is_running():
            return

        answer = QMessageBox.question(
            self,
            "Выключение",
            "Это принудительная остановка QEMU.\n"
            "Сначала завершите работу Windows "
            "внутри виртуальной машины.\n\n"
            "Продолжить?"
        )

        if answer == QMessageBox.Yes:
            self.vm.stop()

    def restart_vm(self):
        if self.vm.is_running():
            answer = QMessageBox.question(
                self,
                "Перезагрузка",
                "Перезапуск принудительно остановит QEMU.\n"
                "Несохранённые данные могут быть потеряны.\n\n"
                "Продолжить?"
            )

            if answer != QMessageBox.Yes:
                return

        try:
            self.save_ui_settings()

            self.vm.restart(
                self.settings,
                use_whpx=check_whpx()
            )

        except Exception as error:
            self.show_error(error)

    def create_snapshot(self):
        name, accepted = QInputDialog.getText(
            self,
            "Создание снимка",
            "Название:"
        )

        if not accepted or not name.strip():
            return

        try:
            self.vm.create_snapshot(
                self.settings,
                name.strip()
            )

            QMessageBox.information(
                self,
                "Готово",
                "Снимок создан."
            )

        except Exception as error:
            self.show_error(error)

    def restore_snapshot(self):
        name, accepted = QInputDialog.getText(
            self,
            "Восстановление",
            "Название снимка:"
        )

        if not accepted or not name.strip():
            return

        try:
            self.vm.restore_snapshot(
                self.settings,
                name.strip()
            )

            QMessageBox.information(
                self,
                "Готово",
                "Снимок восстановлен."
            )

        except Exception as error:
            self.show_error(error)

    def list_snapshots(self):
        try:
            result = self.vm.qemu.list_snapshots(
                self.settings["disk"]
            )

            QMessageBox.information(
                self,
                "Снимки",
                result or "Снимков нет"
            )

        except Exception as error:
            self.show_error(error)

    def update_status(self):
        running = self.vm.is_running()

        self.status.setText(
            "● Windows запущена"
            if running
            else "● Windows выключена"
        )

        self.start_button.setEnabled(
            not running
        )

        self.create_button.setEnabled(
            not running
        )

        self.stop_button.setEnabled(
            running
        )

        self.cpu_spin.setEnabled(
            not running
        )

        self.ram_spin.setEnabled(
            not running
        )

        self.disk_spin.setEnabled(
            not running
        )

        self.snapshot_button.setEnabled(
            not running
        )

        self.restore_button.setEnabled(
            not running
        )

        cpu = psutil.cpu_percent()

        ram = psutil.virtual_memory().percent

        self.cpu_progress.setValue(
            int(cpu)
        )

        self.ram_progress.setValue(
            int(ram)
        )

        self.cpu_label.setText(
            f"CPU компьютера: {cpu}%"
        )

        self.ram_label.setText(
            f"RAM компьютера: {ram}%"
        )

    def closeEvent(self, event):
        if self.vm.is_running():
            QMessageBox.warning(
                self,
                "Виртуальная машина работает",
                "Сначала выключите виртуальную машину."
            )

            event.ignore()
            return

        self.save_ui_settings()

        event.accept()