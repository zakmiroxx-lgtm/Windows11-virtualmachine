import sys

from PySide6.QtWidgets import QApplication

from .gui import MainWindow


def main():
    app = QApplication(sys.argv)

    app.setApplicationName(
        "Windows11 Virtual Machine"
    )

    app.setOrganizationName(
        "Windows11VirtualMachine"
    )

    window = MainWindow()
    window.show()

    return app.exec()


if __name__ == "__main__":
    sys.exit(main())