import subprocess
import sys

from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent

DIST = ROOT / "dist"


def build():
    command = [
        sys.executable,
        "-m",
        "PyInstaller",

        "--noconfirm",
        "--clean",
        "--windowed",
        "--onedir",

        "--name",
        "Windows11VirtualMachine",

        "--distpath",
        str(DIST),

        "--paths",
        str(ROOT),

        str(ROOT / "launcher.py")
    ]

    subprocess.run(
        command,
        check=True,
        cwd=ROOT
    )


if __name__ == "__main__":
    build()