import os
import platform
import subprocess

import psutil


def get_hardware_info():
    memory = psutil.virtual_memory()

    return {
        "system": platform.system(),
        "architecture": platform.machine(),
        "cpu_count": os.cpu_count() or 1,
        "ram_total": round(memory.total / (1024 ** 3), 2),
        "ram_available": round(memory.available / (1024 ** 3), 2)
    }


def check_whpx():
    if platform.system() != "Windows":
        return False

    try:
        result = subprocess.run(
            [
                "powershell.exe",
                "-NoProfile",
                "-NonInteractive",
                "-Command",
                "(Get-WindowsOptionalFeature -Online -FeatureName HypervisorPlatform).State"
            ],
            capture_output=True,
            text=True,
            timeout=30
        )

        return (
            result.returncode == 0
            and result.stdout.strip().lower() == "enabled"
        )

    except (OSError, subprocess.TimeoutExpired):
        return False


def enable_whpx():
    if platform.system() != "Windows":
        raise RuntimeError("WHPX requires Windows")

    return subprocess.run(
        [
            "dism",
            "/online",
            "/Enable-Feature",
            "/FeatureName:HypervisorPlatform",
            "/All",
            "/NoRestart"
        ],
        capture_output=True,
        text=True,
        timeout=180
    )