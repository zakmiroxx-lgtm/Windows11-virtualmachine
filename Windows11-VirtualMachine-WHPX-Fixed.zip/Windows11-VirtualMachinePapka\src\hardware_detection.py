import ctypes
import os
import platform
import subprocess

import psutil


def get_hardware_info():
    memory = psutil.virtual_memory()

    return {
        "system": platform.system(),
        "architecture": platform.machine(),
        "cpu_count": os.cpu_count() or 1,
        "ram_total": round(
            memory.total / (1024 ** 3), 2
        ),
        "ram_available": round(
            memory.available / (1024 ** 3), 2
        )
    }


def check_whpx():
    """
    Check Windows Hypervisor Platform through Windows API.

    Does not require administrator privileges.
    """

    if platform.system() != "Windows":
        return False

    try:
        whp = ctypes.WinDLL("WinHvPlatform.dll")

        get_capability = whp.WHvGetCapability

        get_capability.argtypes = [
            ctypes.c_uint32,
            ctypes.c_void_p,
            ctypes.c_uint32,
            ctypes.POINTER(ctypes.c_uint32)
        ]

        get_capability.restype = ctypes.c_long

        # WHvCapabilityCodeHypervisorPresent = 0
        capability_code = 0

        present = ctypes.c_uint32(0)

        written = ctypes.c_uint32(0)

        result = get_capability(
            capability_code,
            ctypes.byref(present),
            ctypes.sizeof(present),
            ctypes.byref(written)
        )

        return (
            result == 0
            and written.value == ctypes.sizeof(present)
            and present.value != 0
        )

    except (OSError, AttributeError, ValueError):
        return False


def enable_whpx():
    """
    Enable Windows Hypervisor Platform.
    Administrator privileges are required.
    """

    if platform.system() != "Windows":
        raise RuntimeError(
            "WHPX requires Windows"
        )

    return subprocess.run(
        [
            "dism",
            "/online",
            "/Enable-Feature",
            "/FeatureName:HypervisorPlatform",
            "/All",
            "/NoRestart"
        ],
        capture_output=True,
        text=True,
        timeout=180
    )