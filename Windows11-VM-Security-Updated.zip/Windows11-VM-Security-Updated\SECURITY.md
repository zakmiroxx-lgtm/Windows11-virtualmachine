# Windows11 Virtual Machine - Security

## Host protection

The application uses QEMU with a virtual QCOW2 disk.

The application does not intentionally attach physical
host disks to the guest.

Host directories are not shared with the guest.

USB passthrough is not enabled.

Networking uses QEMU user-mode networking.

No host port forwarding is configured.

## Important limitations

Virtualization does not guarantee complete isolation.

QEMU vulnerabilities may affect host security.

Guest networking is not a complete security boundary.

A malicious or compromised host application can access
files permitted by the host user account.

The application should not be run as administrator.

## Windows 11

TPM 2.0 integration is not yet implemented.

UEFI firmware must be supplied with the QEMU package.

Secure Boot is not automatically configured.

Windows 11 installation is not yet validated.

## Backups

Keep backups of important personal files.

Do not rely on virtual machine snapshots as the only
backup mechanism.