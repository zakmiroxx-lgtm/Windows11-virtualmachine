import os
import shutil
import subprocess
import sys

from pathlib import Path

from .settings import APP_DIR


def application_root():

    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent

    return Path(__file__).resolve().parent.parent


class QEMUManager:

    def __init__(self):

        self.root = application_root()

        self.qemu_dir = self.root / "qemu"

        self.qemu_exe = (
            self.qemu_dir / "qemu-system-x86_64.exe"
        )

        self.qemu_img = (
            self.qemu_dir / "qemu-img.exe"
        )

        self.vm_dir = APP_DIR / "vm"

        self.vm_dir.mkdir(
            parents=True,
            exist_ok=True
        )

        self.nvram = self.vm_dir / "uefi_vars.fd"

    def check_installation(self):

        return (
            self.qemu_exe.is_file()
            and self.qemu_img.is_file()
        )

    def validate_disk(self, disk):

        disk = Path(disk).resolve()

        allowed = APP_DIR.resolve()

        if not disk.is_relative_to(allowed):
            raise ValueError(
                "Virtual disk must be inside application data directory"
            )

        if disk.suffix.lower() != ".qcow2":
            raise ValueError(
                "Only QCOW2 virtual disks are allowed"
            )

        if disk.is_symlink():
            raise ValueError(
                "Symbolic links are not allowed"
            )

        return disk

    def find_uefi(self):

        candidates = [
            "edk2-x86_64-code.fd",
            "OVMF_CODE.fd",
            "share/edk2-x86_64-code.fd",
            "share/OVMF_CODE.fd",
            "share/edk2-x86_64-code-4m.fd"
        ]

        for name in candidates:

            path = self.qemu_dir / name

            if path.is_file():
                return path

        return None

    def find_uefi_vars(self):

        candidates = [
            "OVMF_VARS.fd",
            "edk2-i386-vars.fd",
            "share/OVMF_VARS.fd",
            "share/edk2-i386-vars.fd",
            "share/edk2-x86_64-vars.fd",
            "share/edk2-x86_64-vars-4m.fd"
        ]

        for name in candidates:

            path = self.qemu_dir / name

            if path.is_file():
                return path

        return None

    def prepare_uefi(self):

        code = self.find_uefi()

        template = self.find_uefi_vars()

        if code is None:
            raise FileNotFoundError(
                "UEFI firmware not found in QEMU package"
            )

        if template is None:
            raise FileNotFoundError(
                "UEFI variables template not found"
            )

        if code.stat().st_size != template.stat().st_size:
            raise RuntimeError(
                "UEFI firmware and variables template sizes differ. "
                "A matching firmware pair is required."
            )

        if not self.nvram.exists():

            shutil.copy2(
                template,
                self.nvram
            )

        if self.nvram.stat().st_size != code.stat().st_size:
            raise RuntimeError(
                "Existing UEFI NVRAM is incompatible with firmware"
            )

        return code, self.nvram

    def create_disk(self, path, size_gb):

        if not self.qemu_img.is_file():
            raise FileNotFoundError(
                "qemu-img.exe not found"
            )

        disk = self.validate_disk(path)

        if disk.exists():
            raise FileExistsError(
                "Virtual disk already exists"
            )

        size_gb = int(size_gb)

        if not 20 <= size_gb <= 2048:
            raise ValueError(
                "Invalid virtual disk size"
            )

        disk.parent.mkdir(
            parents=True,
            exist_ok=True
        )

        subprocess.run(
            [
                str(self.qemu_img),
                "create",
                "-f",
                "qcow2",
                str(disk),
                f"{size_gb}G"
            ],
            check=True,
            timeout=120,
            cwd=str(self.qemu_dir)
        )

    def build_command(
        self,
        settings,
        use_whpx=True
    ):

        if not self.check_installation():
            raise FileNotFoundError(
                "QEMU components are missing"
            )

        disk = self.validate_disk(
            settings["disk"]
        )

        if not disk.is_file():
            raise FileNotFoundError(
                "Virtual disk not found"
            )

        ram = int(settings["ram"])

        cpu = int(settings["cpu"])

        if not 1024 <= ram <= 65536:
            raise ValueError(
                "Invalid RAM allocation"
            )

        if not 1 <= cpu <= (os.cpu_count() or 1):
            raise ValueError(
                "Invalid CPU allocation"
            )

        firmware, nvram = self.prepare_uefi()

        command = [
            str(self.qemu_exe),

            "-machine",
            "q35",

            "-m",
            str(ram),

            "-smp",
            str(cpu),

            "-drive",
            (
                "if=pflash,"
                "format=raw,"
                "readonly=on,"
                f"file={firmware}"
            ),

            "-drive",
            (
                "if=pflash,"
                "format=raw,"
                f"file={nvram}"
            ),

            "-drive",
            (
                f"file={disk},"
                "format=qcow2,"
                "if=ide"
            ),

            "-device",
            "qemu-xhci",

            "-device",
            "usb-tablet",

            "-device",
            "usb-kbd",

            "-nic",
            "user,model=e1000",

            "-vga",
            "std",

            "-display",
            "sdl",

            "-audiodev",
            "dsound,id=audio0",

            "-device",
            "ich9-intel-hda",

            "-device",
            "hda-output,audiodev=audio0",

            "-monitor",
            "none"
        ]

        if use_whpx:

            command.extend([
                "-accel",
                "whpx"
            ])

        else:

            command.extend([
                "-accel",
                "tcg"
            ])

        iso = settings.get("iso", "")

        if iso:

            iso_path = Path(iso).resolve()

            if not iso_path.is_file():
                raise FileNotFoundError(
                    "Windows ISO not found"
                )

            if iso_path.suffix.lower() != ".iso":
                raise ValueError(
                    "Installation media must be an ISO file"
                )

            command.extend([
                "-drive",
                (
                    f"file={iso_path},"
                    "media=cdrom,"
                    "if=ide,"
                    "readonly=on"
                ),

                "-boot",
                "order=d"
            ])

        return command

    def create_snapshot(self, disk, name):

        disk = self.validate_disk(disk)

        if not name or len(name) > 64:
            raise ValueError(
                "Invalid snapshot name"
            )

        subprocess.run(
            [
                str(self.qemu_img),
                "snapshot",
                "-c",
                name,
                str(disk)
            ],
            check=True,
            timeout=120
        )

    def restore_snapshot(self, disk, name):

        disk = self.validate_disk(disk)

        subprocess.run(
            [
                str(self.qemu_img),
                "snapshot",
                "-a",
                name,
                str(disk)
            ],
            check=True,
            timeout=120
        )

    def list_snapshots(self, disk):

        disk = self.validate_disk(disk)

        result = subprocess.run(
            [
                str(self.qemu_img),
                "snapshot",
                "-l",
                str(disk)
            ],
            capture_output=True,
            text=True,
            check=True,
            timeout=120
        )

        return result.stdout