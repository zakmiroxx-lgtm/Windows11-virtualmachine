import json
import os

from pathlib import Path


APP_NAME = "Windows11VirtualMachine"


def get_app_dir():

    base = os.environ.get(
        "LOCALAPPDATA",
        str(Path.home())
    )

    directory = Path(base) / APP_NAME

    directory.mkdir(
        parents=True,
        exist_ok=True
    )

    return directory


APP_DIR = get_app_dir()

VM_DIR = APP_DIR / "vm"

VM_DIR.mkdir(
    parents=True,
    exist_ok=True
)

SETTINGS_FILE = APP_DIR / "settings.json"


DEFAULT_SETTINGS = {
    "ram": 8192,
    "cpu": 4,
    "disk_size": 80,
    "iso": "",
    "disk": str(VM_DIR / "windows.qcow2")
}


def load_settings():

    settings = DEFAULT_SETTINGS.copy()

    if SETTINGS_FILE.exists():

        try:

            with open(
                SETTINGS_FILE,
                "r",
                encoding="utf-8"
            ) as file:

                loaded = json.load(file)

            if isinstance(loaded, dict):

                for key in (
                    "ram",
                    "cpu",
                    "disk_size",
                    "iso"
                ):

                    if key in loaded:
                        settings[key] = loaded[key]

        except (OSError, ValueError, TypeError):
            pass

    settings["disk"] = DEFAULT_SETTINGS["disk"]

    return settings


def save_settings(settings):

    safe = DEFAULT_SETTINGS.copy()

    for key in (
        "ram",
        "cpu",
        "disk_size",
        "iso"
    ):

        if key in settings:
            safe[key] = settings[key]

    temporary = SETTINGS_FILE.with_suffix(".tmp")

    with open(
        temporary,
        "w",
        encoding="utf-8"
    ) as file:

        json.dump(
            safe,
            file,
            indent=4,
            ensure_ascii=False
        )

    temporary.replace(SETTINGS_FILE)